<?php
Route::get('zf_bdtongji2', '/addons/zf_bdtongji.index/index');