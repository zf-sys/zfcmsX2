<?php
return [
    "plugin_name"=>"zf_bdtongji",
    "name"=>"百度统计",
    "version"=>"v1.0.0",
    "pic"=>"",
    "ctime"=>"2021-05-26",
    "author"=>"zf",
    "soft_id"=>"14bfa6bb14875e45bba028a21ed38046"
];