<?php
namespace app\addons\zf_bdtongji\controller;
use app\addons\controller\Base as Bas;
use think\Controller;

class Base extends Bas
{
    protected function initialize(){
        // $this->view->filter(function($content){
        //     $find = array('~>\s+<~', '~>(\s+)~', '~(\s+)<~','~[\r\n]+~', '~[\s]{2,}~');
        //     $replace = array('><', '>', '<', ' ', ' ');
        //     $content = preg_replace($find, $replace, $content);
        //     return $content;
        // });
    }
    public function __construct()
    {
        parent::__construct();
        if(!session('admin')){
            session('zf_login_tap_url',request()->url());
            $this->error('请先登录','/admin');
        }
        $AdFunction = new \app\addons\controller\Base();
        $parm_data = $AdFunction->get_config('zf_bdtongji','config','db');
        $this->plugin_name =  'zf_bdtongji';
        $this->tb_pre = $parm_data['tb'];
        $this->parm_data = $parm_data;
        $this->assign('tb_pre',$this->tb_pre );
        $this->assign('parm_data',$parm_data );

        $_name = $c =  strtolower(request()->controller());

    }
   


}

?>