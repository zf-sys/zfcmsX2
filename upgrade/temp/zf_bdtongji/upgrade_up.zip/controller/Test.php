<?php
// +----------------------------------------------------------------------
// | 子枫后台管理系统(TpFast系列)[基于ThinkPHP5.1开发]
// +----------------------------------------------------------------------
// | Copyright (c)  http://v1.fast.zf.90ckm.com/
// | 子枫后台管理系统提供免费使用,可使用此框架进行二次开发
// +----------------------------------------------------------------------
// | Author: 子枫 <287851074@qq.com>
// +----------------------------------------------------------------------
// | github:https://github.com/wmc1125/zfAdmin_tpfast
// | 码云:  https://gitee.com/wmc1125/zfAdmin_tpfast
// | Mc技术论坛: http://bbs.wangmingchang.com/forum.php?mod=forumdisplay&fid=77
// +----------------------------------------------------------------------
namespace app\addons\zf_bdtongji\controller;
use Wmc1125\TpFast\Category as cat; 
use think\Db;
use Wmc1125\TpFast\GetImgSrc; 
use think\Controller;
  
class Test extends Controller
{
    public function __construct (){
        parent::__construct();
        // // 跨域(解决跨域问题)
        // header('Access-Control-Allow-Origin: *');
        // header("Access-Control-Allow-Headers:Origin, X-Requested-With, Content-Type, Accept,Authorization");
        // header('Access-Control-Allow-Methods: POST,GET');
        // if(request()->isOptions()){ exit;}

        $AdFunction = new \app\addons\controller\Base();
        $this->parm_data = $AdFunction->get_config('zf_bdtongji','config','db');
        // $this->tb_pre = $parm_data['tb'];
    }
    public function index(){
    }
    public function test(){
        $url = 'https://api.baidu.com/json/tongji/v1/ReportService/getData';
        $post['header'] = [
            "username"=>$this->parm_data['bd_user'],
            "password"=>$this->parm_data['bd_pwd'],
            "token"=>$this->parm_data['bd_token'],
            "account_type"=>1
        ];
        $post['body'] = [
            "site_id"=> $this->parm_data['bd_siteid'],
            "start_date"=> "20210525",
            "end_date"=> "20210526",
            "metrics"=> "pv_count,visitor_count,ip_count",
            "method"=> "overview/getTimeTrendRpt"
        ];

        $res = https_post($url,json_encode($post));
        dd($res);
    }
    // 获取列表
    public function get_site_list(){
        $url = 'https://api.baidu.com/json/tongji/v1/ReportService/getSiteList';
        $post['header'] = [
            "username"=>$this->parm_data['bd_user'],
            "password"=>$this->parm_data['bd_pwd'],
            "token"=>$this->parm_data['bd_token'],
            "account_type"=>1
        ];
        $res = https_post($url,json_encode($post));
        dd($res);
    }

// 网站概况
//      包含今日流量概况与昨日流量对比、历史峰值对比，趋势分析，新老访客，Top10搜索词，Top10来源网站，Top10入口页面，Top10受访页面。
// 实时访客
//      查询实时访客数据，包含时间、来源、ip、入口页面、操作系统、浏览器、访问时长等。
// 访客来源
// 受访页面
// 地域分布
//      分为按国内省份和按国家查询。
// 搜索词
// 关键词排名
//      若已在百度统计官方后台设置关键词可点击同步按钮，若尚未设置可以通过点击设置按钮添加关键词，最多增加10个关键词


    

    
    
    
}

