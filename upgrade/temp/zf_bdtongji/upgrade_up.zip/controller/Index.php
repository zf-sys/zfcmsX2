<?php
namespace addons\zf_bdtongji\controller;
use think\addons\Controller;
use think\Db;
use OSS\OssClient as AliOssClient;
use Wmc1125\TpFast\GetImgSrc;
class Index extends Controller
{
    public function __construct()
    {
        parent::__construct();
        if(!session('admin')){
            session('zf_login_tap_url',request()->url());
            $this->error('请先登录','/admin');
        }
    }
    // http://plugintest.v1.fast.zf.90ckm.com/addons/zf_bdtongji.index/index
    public function index(){
        $url = input('url','');
        $this->assign('url',$url);
        $menu = [
            [
                'name'=>'网站概况',
                'icon'=>'mdi-settings-box',
                'url'=>$this->site_path.'addons/zf_bdtongji.data/wzgk'
            ],
            [
                'name'=>'实时访客',
                'icon'=>'mdi-leaf',
                'url'=>$this->site_path.'addons/zf_bdtongji.data/ssfk'
            ],
            [
                'name'=>'访客来源',
                'icon'=>'mdi-layers',
                'url'=>$this->site_path.'addons/zf_bdtongji.data/fkly',
            ],
            [
                'name'=>'受访页面',
                'url'=>$this->site_path.'addons/zf_bdtongji.data/sfym'
            ],
            [
                'name'=>'地域分布',
                'icon'=>'mdi-lead-pencil',
                'url'=>$this->site_path.'addons/zf_bdtongji.data/qyfb'
            ],
            [
                'name'=>'地域分布(国家)',
                'icon'=>'mdi-lead-pencil',
                'url'=>$this->site_path.'addons/zf_bdtongji.data/qyfb_gj'
            ],
            [
                'name'=>'搜索词',
                'icon'=>'mdi-lead-pencil',
                'url'=>$this->site_path.'addons/zf_bdtongji.data/ssc'
            ],
            // [
            //     'name'=>'关键词排名',
            //     'icon'=>'mdi-lead-pencil',
            //     'url'=>$this->site_path.'addons/zf_bdtongji.data/gjc'
            // ]
           
           
        ];





        $this->assign('menu',$menu);

        return view();

    }
    public function welcome(){
    
        return view();
    }
    public function setting(){
        $t = input('t','');
        $this->assign('t',$t);
        $AdFunction = new \app\addons\controller\Base();
        if(request()->isPost()){
            $res = $AdFunction->save_config(input('post.'),'zf_bdtongji','config','db');
            if($res){
                return jssuccess('保存成功');die;
            }else{
                return jserror('保存失败');die;
            }
        }
        $data = $AdFunction->get_config('zf_bdtongji','config','db');
        if(!isset($data['template_home'])){
            $data['template_home'] = '';
        }
        if(!isset($data['cate_editor_def'])){
            $data['cate_editor_def'] = '';
        }
        if(!isset($data['editor_def'])){
            $data['editor_def'] = '';
        }
        $this->assign("data",$data);
        return view();
    }
    
    

}

?>