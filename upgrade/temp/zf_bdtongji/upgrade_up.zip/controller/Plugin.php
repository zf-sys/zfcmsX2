<?php
namespace addons\zf_bdtongji\controller;
use think\addons\Controller;


class Plugin extends Controller
{
    
    public function __construct()
    {
        parent::__construct();
        

    }
    public function index(){
        echo "欢迎使用<br>";
        echo "<a href='/addons/zf_bdtongji.index/index' target='_blank'>点击进入首页</a>";

    }

    public function _empty(){
        echo "没有此方法";die;
    }

    
    public function install()
    {
        return ["code"=>1,"msg"=>"ok"];
    }

   
    public function uninstall()
    {
        return ["code"=>1,"msg"=>"ok"];
    }
    public function hook()
    {
    }



}