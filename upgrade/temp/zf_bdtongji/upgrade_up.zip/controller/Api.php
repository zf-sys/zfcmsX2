<?php
// +----------------------------------------------------------------------
// | 子枫后台管理系统(TpFast系列)[基于ThinkPHP5.1开发]
// +----------------------------------------------------------------------
// | Copyright (c)  http://v1.fast.zf.90ckm.com/
// | 子枫后台管理系统提供免费使用,可使用此框架进行二次开发
// +----------------------------------------------------------------------
// | Author: 子枫 <287851074@qq.com>
// +----------------------------------------------------------------------
// | github:https://github.com/wmc1125/zfAdmin_tpfast
// | 码云:  https://gitee.com/wmc1125/zfAdmin_tpfast
// | Mc技术论坛: http://bbs.wangmingchang.com/forum.php?mod=forumdisplay&fid=77
// +----------------------------------------------------------------------
namespace app\addons\zf_bdtongji\controller;
use Wmc1125\TpFast\Category as cat; 
use think\Db;
use Wmc1125\TpFast\GetImgSrc; 
use think\Controller;
  
class Api extends Controller
{
    public function __construct (){
        parent::__construct();
        // // 跨域(解决跨域问题)
        // header('Access-Control-Allow-Origin: *');
        // header("Access-Control-Allow-Headers:Origin, X-Requested-With, Content-Type, Accept,Authorization");
        // header('Access-Control-Allow-Methods: POST,GET');
        // if(request()->isOptions()){ exit;}

        // $AdFunction = new \app\addons\controller\Base();
        // $parm_data = $AdFunction->get_config('zf_bdtongji','config','db');
        // $this->tb_pre = $parm_data['tb'];
    }
    public function index(){
    }

    //https://plugintest.v1.fast.zf.90ckm.com/addons/zf_bdtongji.api/auto_login?token=111
    public function auto_login(){
        $token_site = config()['web']['site_token'];
        $token = input('token','');
        if($token==''){
            echo 'token不能为空';die;
        }
        if($token!=$token_site){
            echo 'token错误';die;
        }
        $admin = db('admin')->where(['name'=>'admin'])->find();
        if(!$admin){
            echo 'admin用户不存在';die;
        }
        session('admin',$admin);

        $this->success('登录成功','/zf_bdtongji');
    }
    

    
    
    
}
