<?php
namespace addons\zf_bdtongji\controller;
use think\addons\Controller;
use think\Db;
use OSS\OssClient as AliOssClient;
use Wmc1125\TpFast\GetImgSrc;
class Data extends Controller
{
    public function __construct()
    {
        parent::__construct();
        if(!session('admin')){
            session('zf_login_tap_url',request()->url());
            $this->error('请先登录','/admin');
        }

        $AdFunction = new \app\common\controller\Base();
        $this->parm_data = $AdFunction->get_config('zf_bdtongji','config','db','addons');

        $this->start_date = date('Ymd',time()-60*60*24);
        $this->end_date = date('Ymd',time());

    }
    
    public function wzgk(){
        $start_date = $this->start_date;
        $end_date = $this->end_date;
        // //趋势
        $post['body'] = [
            "site_id"=> $this->parm_data['bd_siteid'],
            "start_date"=> $start_date,
            "end_date"=> $end_date,
            "metrics"=> "pv_count,visitor_count,ip_count,bounce_ratio,avg_visit_time,trans_count",
            "method"=> "overview/getTimeTrendRpt"
        ];
        // pv_count (浏览量PV)  // visitor_count (访客数UV)  // ip_count (IP 数)  // bounce_ratio (跳出率，%)  // avg_visit_time (平均访问时长，秒)  // trans_count (转化次数)
        $_res = $this->get_data_bdtj('https://api.baidu.com/json/tongji/v1/ReportService/getData',$post);
        $data['qs'] = json_decode($_res,true);


        // //来源/搜索
        $post['body'] = [
            "site_id"=> $this->parm_data['bd_siteid'],
            "start_date"=> $start_date,
            "end_date"=> $end_date,
            "metrics"=> "",
            "method"=> "overview/getCommonTrackRpt"
        ];
        $_res = $this->get_data_bdtj('https://api.baidu.com/json/tongji/v1/ReportService/getData',$post);
        $data['lyssc'] = json_decode($_res,true);
        // dd($data['lyssc']);

        // //趋势分析 https://tongji.baidu.com/api/manual/Chapter1/trend_time_a.html
        $post['body'] = [
            "site_id"=> $this->parm_data['bd_siteid'],
            "start_date"=> $start_date,
            "end_date"=> $end_date,
            "metrics"=>"pv_count,avg_visit_time",
            "method"=>"trend/time/a",
            "gran"=>"day",
            "source"=>"through",
            "clientDevice"=>"pc",
            "area"=>"china"
        ];
        $_res = $this->get_data_bdtj('https://api.baidu.com/json/tongji/v1/ReportService/getData',$post);
        $data['qsfx'] = json_decode($_res,true);

        // dd($data['qsfx']);
        //搜索词
        $post['body'] = [
            "site_id"=> $this->parm_data['bd_siteid'],
            "start_date"=> $start_date,
            "end_date"=> $end_date,
            "metrics"=>"pv_count,visit_count,visitor_count",
            "method"=>"source/searchword/a",
        ];
        $_res = $this->get_data_bdtj('https://api.baidu.com/json/tongji/v1/ReportService/getData',$post);
        $data['ssc'] = json_decode($_res,true);
        
        // dd($data['ssc']);


        $this->assign('data',$data);
        return view();
    }
    public function ssfk(){
        $start_date = $this->start_date;
        $end_date = $this->end_date;
        $post['body'] = [
            "site_id"=> $this->parm_data['bd_siteid'],
            "start_date"=> $start_date,
            "end_date"=> $end_date,
            "metrics"=> "start_time,area,source,access_page,keyword,searchword,is_ad,visitorId,ip,visit_time,visit_pages",
            "method"=> "trend/latest/a"
        ];
        $_res = $this->get_data_bdtj('https://api.baidu.com/json/tongji/v1/ReportService/getData',$post);
        $data['ssfk'] = json_decode($_res,true);

    // dd($data['ssfk']);
        $this->assign('data',$data);
        return view();
    }
    // 访客来源
    public function fkly(){
        $start_date = $this->start_date;
        $end_date = $this->end_date;
        $post['body'] = [
            "site_id"=> $this->parm_data['bd_siteid'],
            "start_date"=> $start_date,
            "end_date"=> $end_date,
            "metrics"=> "",
            "method"=> "overview/getCommonTrackRpt"
        ];
        $_res = $this->get_data_bdtj('https://api.baidu.com/json/tongji/v1/ReportService/getData',$post);
        $data['lyssc'] = json_decode($_res,true);

    // dd($data['lyssc']);
        $this->assign('data',$data);
        return view();
    }
    // 受访页面
    public function sfym(){
        $start_date = $this->start_date;
        $end_date = $this->end_date;
        $post['body'] = [
            "site_id"=> $this->parm_data['bd_siteid'],
            "start_date"=> $start_date,
            "end_date"=> $end_date,
            "metrics"=> "pv_count,visitor_count,ip_count,visit1_count,outward_count,exit_count,exit_ratio,average_stay_time",
            "method"=> "visit/toppage/a"
        ];
        $_res = $this->get_data_bdtj('https://api.baidu.com/json/tongji/v1/ReportService/getData',$post);
        $data['sfym'] = json_decode($_res,true);

    // dd($data['sfym']);
        $this->assign('data',$data);
        return view();
    }
    // 区域分布
    public function qyfb(){
        $start_date = $this->start_date;
        $end_date = $this->end_date;
        $post['body'] = [
            "site_id"=> $this->parm_data['bd_siteid'],
            "start_date"=> $start_date,
            "end_date"=> $end_date,
            "metrics"=> "pv_count,pv_ratio,visit_count,visitor_count,new_visitor_count,new_visitor_ratio,ip_count,bounce_ratio,avg_visit_time,avg_visit_pages,trans_count,trans_ratio",
            "method"=> "visit/district/a"
        ];
        $_res = $this->get_data_bdtj('https://api.baidu.com/json/tongji/v1/ReportService/getData',$post);
        $data['qyfb'] = json_decode($_res,true);

    // dd($data['qyfb']);
        $this->assign('data',$data);
        return view();
        return view();
    }
    public function qyfb_gj(){
        $start_date = $this->start_date;
        $end_date = $this->end_date;
        $post['body'] = [
            "site_id"=> $this->parm_data['bd_siteid'],
            "start_date"=> $start_date,
            "end_date"=> $end_date,
            "metrics"=> "pv_count,pv_ratio,visit_count,visitor_count,new_visitor_count,new_visitor_ratio,ip_count,bounce_ratio,avg_visit_time,avg_visit_pages,trans_count,trans_ratio",
            "method"=> "visit/world/a"
        ];
        $_res = $this->get_data_bdtj('https://api.baidu.com/json/tongji/v1/ReportService/getData',$post);
        $data['qyfb'] = json_decode($_res,true);

    // dd($data['qyfb']);
        $this->assign('data',$data);
        return view();
    }
    public function ssc(){
        $start_date = $this->start_date;
        $end_date = $this->end_date;
        $post['body'] = [
            "site_id"=> $this->parm_data['bd_siteid'],
            "start_date"=> $start_date,
            "end_date"=> $end_date,
            "metrics"=>"pv_count,visit_count,visitor_count",
            "method"=>"source/searchword/a",
        ];
        $_res = $this->get_data_bdtj('https://api.baidu.com/json/tongji/v1/ReportService/getData',$post);
        $data['ssc'] = json_decode($_res,true);
        $this->assign('data',$data);
        return view();
    }
    public function gjc(){
    
        return view();
    }



    private function get_data_bdtj($url='',$post=[]){
        $post['header'] = [
            "username"=>$this->parm_data['bd_user'],
            "password"=>$this->parm_data['bd_pwd'],
            "token"=>$this->parm_data['bd_token'],
            "account_type"=>1
        ];
        $res = https_post($url,json_encode($post));
        return $res;
    }



}

