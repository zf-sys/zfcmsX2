<?php
// 插件信息最后修改于 2021/05/26 09:52:41  
  
 return [
	'bd_user' => 'wmc1125',
	'bd_pwd' => '2022jiayouBD',
	'bd_token' => 'c472217f4e50640b4d53386d87de0f72',
	'bd_siteid' => '16783083',
];